object Happy extends App {
  // todo: write these functions!
  def sumOfDigitsSquared(n: Int): Int = 0
  def isHappy(n: Int): Boolean = false
  def kThHappy(k: Int): Int = 0
 }
