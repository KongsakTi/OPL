object Aggregate extends App {
  // todo: implement these functions for real!
  def myMin(p: Double, q: Double, r: Double): Double = 0.0 
  def myMean(p: Double, q: Double, r: Double): Double = 0.0
  def myMed(p: Double, q: Double, r: Double): Double = 0.0
}
