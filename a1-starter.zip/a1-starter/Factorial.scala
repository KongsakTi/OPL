object Factorial extends App {
  def factorial(n: Int): Long = 0 // todo: write real code
}
